package com.exampledemo.parsaniahardik.jsonparsing;

/**
 * Created by Parsania Hardik on 19-Apr-17.
 */
public class PlayersModel {

    private String name, country, city;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
